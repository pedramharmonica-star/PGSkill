# -*- coding: utf-8 -*-
"""Example data for build_proposal.py: a FICTIONAL customer (شرکت نمونه). Copy this file outside the repo,
fill it from the customer's RFP or meeting notes, and build. Every field below is read by the builder.

Rules that decide the content (references/proposal-structure.md):
- edition: standard unless an enterprise condition holds; on-prem unless cloud is asked for
- ROWS status: K = کامل، J = جزئی (with condition or alternative in field 7), F = فاقد
- anything the sources do not answer: ask the user first; if built anyway, write [[نیازمند تأیید تیم فنی]]
- reports: say "ready" only for an exact-title match; otherwise "با گزارش‌ساز ساخته می‌شود (شخصی‌سازی)"
- hours only (15 h ~ 2 processes), no weekly schedule, no session counts
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import charts as CH

CLIENT = 'شرکت نمونه'                 # full name on the cover
CLIENT_SHORT = 'نمونه'                 # short name inside sentences ("نیاز نمونه")
AGENT_WORD = 'نماینده'                 # who uses the agents club
FOOTER = 'پیشنهاد فنی پیام‌گستر برای شرکت نمونه'
COVER_KICKER = 'پاسخ فنی به درخواست پیشنهاد <bdi>RFP-0000</bdi>'   # '' if there is no RFP
COVER_TITLE = 'سامانه یکپارچه مدیریت ارتباط با مشتری'
COVER_SUB = 'ثبت سرنخ، فروش، خدمات پس از فروش و باشگاه مشتریان روی یک پرونده برای هر مشتری'
DATE = 'آبان ۱۴۰۵'
ATTACHMENT = 'پیش‌فاکتور'
VERSION = '2.8.8'
NEED_SOURCE = 'شناسه‌دار درخواست پیشنهاد'

EXEC_TITLE = 'یک پرونده برای هر مشتری و یک مسئول برای هر درخواست'
EXEC_LEAD = 'شرکت نمونه سامانه‌ای می‌خواهد که سرنخ‌ها، فروش و درخواست‌های خدمت را روی یک پرونده برای هر مشتری نگه دارد. پیشنهاد پیام‌گستر، نرم‌افزار مدیریت ارتباط با مشتری <b>ویرایش استاندارد</b> است که روی سرور شرکت نمونه نصب می‌شود.'
EXEC_COLS = [('آماده در نرم‌افزار', 'پرونده شخص و سازمان، فرصت فروش، تیکتینگ، باشگاه مشتریان، پیامک، فرم‌ساز و موتور فرایند (BPMS).'),
             ('با استقرار ساخته می‌شود', 'فرم‌ها و ۴ فرایند شرکت نمونه، در ۳۰ نفرساعت استقرار.'),
             ('شخصی‌سازی است', 'اتصال فرم‌های سایت، گزارش‌هایی که گزارش آماده هم‌نام ندارند، و انتقال داده‌ها به‌جز هویت‌ها.')]
EDITION_LINE = 'ویرایش استاندارد، نصب درون‌سازمانی روی سرور شرکت نمونه.'

NEEDS = [('user', 'پرونده یکپارچه مشتری', 'هر مشتری یک پرونده با همه تماس‌ها، خریدها و درخواست‌ها.'),
         ('chart', 'پیگیری فروش', 'هر سرنخ منبع، مسئول و اقدام بعدی داشته باشد.'),
         ('chat', 'خدمات پس از فروش', 'هر درخواست شماره، موعد پاسخ و مسئول داشته باشد.'),
         ('star', 'باشگاه مشتریان', 'مشتری سوابق و درخواست‌هایش را در پنل خودش ببیند.'),
         ('send', 'پیامک و ایمیل', 'اطلاع‌رسانی به مشتری در هر مرحله.'),
         ('shield', 'دسترسی و امنیت', 'هر کاربر فقط داده مجاز را ببیند.')]
SCOPE = '<b>خارج از دامنه:</b> حسابداری و انبارداری. اتصال به این سامانه‌ها در دامنه این پیشنهاد نیست؛ وب‌سرویس مستند پیام‌گستر در اختیار شرکت نمونه است.'
CUSTOMER_LOGOS = ['nestle', 'pegah', 'mihan', 'irib', 'arvancloud', 'respina', 'datis', 'skyroom']   # assets/customer-logos/
LOGO_NOTE = 'فهرست کامل سوابق در جلسه ارزیابی ارائه می‌شود.'
AUDIENCES = [('مشتری خرد', 'سرنخ، فرصت، فاکتور'), ('مشتری سازمانی', 'فرصت سازمانی، قرارداد'), ('نماینده فروش', 'پنل نمایندگان')]
COMPONENTS = [('کنسول مدیریت ارتباط با مشتری', 'پرونده ۳۶۰، دسترسی'), ('فرم‌ساز و BPMS', 'مسیرها و تأییدها'), ('درخواست‌ها و قراردادها', 'تیکت، قرارداد'), ('باشگاه مشتریان', 'پنل مشتری')]
CORE_TEXT = 'شخص، سازمان، فرصت و درخواست'
# optional (non-CRM proposals, e.g. office automation): MAP_TITLE, AUD_TITLE, CORE_TITLE (centre of the solution map),
# SHOW_CLUB_LIMITS = False (hide agents/customers club meters on the edition page),
# IMPORT_STEP = (icon, title, text, output) for roadmap step 4, SEC_USERS (first step of the data-path flow)
# EDITION_SIMPLE = True (solution-based proposals: only the standard limits, no standard-vs-enterprise text),
# DEP_GENERAL = [(title, text)] with PROCS = [] (deployment page says only the hours and what happens in them)
# compliance table: long categories split over pages automatically (rows packed by estimated height, spread evenly);
# TABLE_H = 700 (usable px per page), TABLE_NOTE = '' (footnote under each table page, e.g. how the RFP status words map)
# EDITION_SIMPLE extras: MAX_USERS = None (count not known yet), EDS_EXTRA = [(icon, number, label, text)] more limit cards
# (e.g. 5000 active club users, 15 active agents), EDS_UP (upgrade line), EDS_FORM_EXAMPLE (example form type)
# status F rows show in grey in the coverage chart and keep their own count on the exec page

U = 'crm.example.ir'
# img: a screenshot crop (assets/screenshots/crops/), or an HTML block (charts) that starts with '<'
SOLUTIONS = [
 dict(no=1, cat='D', catname='پرونده یکپارچه', title='پرونده یکپارچه مشتری', need='هر مشتری یک پرونده با همه ارتباط‌ها و بدون پرونده تکراری.',
      caps=[('هویت یکتا', 'موبایل، کد ملی و کد اقتصادی تکراری ثبت نمی‌شود.'), ('پرونده ۳۶۰', 'تماس، پیامک، فرصت و درخواست‌ها در یک صفحه.'),
            ('خط زمانی', 'همه رویدادهای مشتری به ترتیب زمان.'), ('ارسال پیام', 'پیامک و ایمیل از همان پرونده.')],
      img='screenshots/crops/c_rec.png', url=U, apptitle=('پرونده', 'سوابق مشتری'), callouts=[(860, 70), (860, 230), (20, 290)],
      legend=['زبانه‌های پرونده', 'خط زمانی ارتباطات', 'ارسال پیام'],
      steps=[('form', 'ثبت مشتری'), ('user', 'کنترل تکرار'), ('chat', 'ثبت تماس'), ('send', 'پیامک'), ('chart', 'گزارش')]),
 dict(no=2, cat='S', catname='فروش', title='قیف فروش و فرصت‌ها', need='هر فرصت مرحله، مسئول و اقدام بعدی روشن داشته باشد.',
      caps=[('نمای کانبان', 'فرصت‌ها به تفکیک مرحله فروش.'), ('اقدام بعدی', 'پیگیری با موعد و یادآوری.'),
            ('دلیل شکست', 'ثبت دلیل موفقیت یا شکست هر فرصت.'), ('پیش‌فاکتور', 'صدور پیش‌فاکتور از فرصت.')],
      img='screenshots/crops/c_kan.png', url=U, apptitle=('فروش', 'قیف فرصت‌ها'), callouts=[(860, 170), (430, 170), (60, 170)],
      legend=['مرحله اول قیف', 'مراحل میانی', 'پایان موفق یا ناموفق'],
      steps=[('form', 'ثبت سرنخ'), ('users', 'ارجاع'), ('cal', 'پیگیری'), ('coin', 'پیش‌فاکتور'), ('check', 'قرارداد')]),
 dict(no=3, cat='K', catname='خدمات', title='درخواست‌های خدمت', need='هر درخواست شماره، موعد پاسخ و مسئول داشته باشد.',
      caps=[('ثبت از همه کانال‌ها', 'پنل، ایمیل، پیامک و تلفن؛ کد رهگیری یکتا.'), ('موعد و ارجاع', 'تایمر پاسخ و ارجاع به مدیر.'),
            ('اختتام', 'تأیید یا اعتراض مشتری از پنل.'), ('نظرسنجی', 'پس از بستن درخواست.')],
      img='screenshots/crops/c_ticket.png', url=U, apptitle=('تیکت', 'درخواست جدید'), callouts=[(860, 112), (860, 280), (380, 112)],
      legend=['عنوان و وضعیت', 'شدت و اولویت', 'کارشناس مسئول'],
      steps=[('chat', 'ثبت درخواست'), ('user', 'ارجاع'), ('clock', 'رسیدگی با موعد'), ('send', 'پاسخ'), ('check', 'نظرسنجی')]),
]
CATS = [('D', 'پرونده یکپارچه'), ('S', 'فروش'), ('K', 'خدمات پس از فروش')]
# (id, priority 'ا۱' = الزام فاز ۱ or '', need, status K/J/F, method, answer, condition/alternative, module, internal note)
ROWS = [
 ('D01', 'ا۱', 'شناسه یکتای مشتری بدون پرونده تکراری', 'K', 'آماده', 'جلوگیری از ثبت موبایل، کد ملی و کد اقتصادی تکراری.', '', 'کنسول', ''),
 ('D02', 'ا۱', 'ادغام دو پرونده تکراری', 'K', 'آماده', 'ادغام با انتقال سوابق از یک پرونده به پرونده دیگر انجام می‌شود.', '', 'کنسول', ''),
 ('S01', 'ا۱', 'قیف فروش با مراحل و دلیل شکست', 'K', 'پیکربندی', 'نوع فرصت با مراحل و نمای کانبان؛ گزارش آماده «گزارش فرصت‌ها» با فیلتر منبع، مرحله و علت.', '', 'مدیریت فرصت‌ها', ''),
 ('S02', 'ا۱', 'دریافت فرم سایت با UTM', 'J', 'API', 'وب‌سرویس فرم و هویت آماده است.', 'اتصال فرم‌های سایت و UTM شخصی‌سازی سمت شرکت نمونه است.', 'وب‌سرویس', ''),
 ('K01', 'ا۱', 'ثبت درخواست از همه کانال‌ها', 'K', 'آماده', 'تیکتینگ از پنل، ایمیل، پیامک و تلفن با کد رهگیری.', '', 'مدیریت درخواست‌ها', ''),
 ('K02', 'ا۱', 'توقف ساعت موعد هنگام انتظار مشتری', 'J', 'پیکربندی', 'موعد پاسخ و حل با تایمر فرایند.', 'توقف ساعت موعد ارائه نمی‌شود.', 'BPMS', ''),
]
KPI = dict(title='نمونه داشبورد شاخص‌ها', panels=[
    ('تبدیل به قرارداد', 'نرخ تبدیل ماهانه', CH.line(['مهر', 'آبان', 'آذر', 'دی'], [8, 10, 9, 12], w=500, h=232, unit='٪', ymax=16)),
    ('زمان پاسخ اولیه', 'میانه، به دقیقه', CH.columns(['مهر', 'آبان', 'آذر', 'دی'], [40, 33, 29, 25], w=500, h=232)),
    ('فرصت به تفکیک منبع', 'تعداد فرصت', CH.hbars([('سایت', 42), ('تماس', 28), ('نمایشگاه', 19)], w=500, label_w=140, bar_h=20, gap=16, size=16, val_w=48))],
    others=['رضایت مشتری'])
TABLE_FORMAT = ''
DEMO = None                    # or [(code, scenario, what we show)]
DEMO_TITLE = ''; DEMO_NOTE = ''

EDITION = 'standard'           # 'standard' or 'enterprise' (then ENTERPRISE_REASONS = [...])
PROCS = ['ارجاع سرنخ', 'فروش', 'درخواست خدمت', 'نظرسنجی']
FORMS = ['پرسش‌نامه نیاز', 'گزارش بازدید']
MAX_USERS = 20; AGENTS = None; CLUB_USERS = None     # None = unknown (shown hatched)
EDITION_TEXT = 'پیام‌گستر دو ویرایش درون‌سازمانی دارد: <b>استاندارد</b> که ماژولار است و <b>پیشرفته (سازمانی)</b>. پیشنهاد ما <b>ویرایش استاندارد</b> است.'
API_SCOPE = ['اتصال فرم‌های سایت و UTM شخصی‌سازی است و شرکت نمونه یا پیمانکارش با همین وب‌سرویس انجام می‌دهد.']
INSTALL_BANDS = [1]; INSTALL_LEGEND = 'ستون رنگی: ۲۰ کاربر شرکت نمونه'
LOM_TITLE = 'ماژول‌های ویرایش استاندارد'
LOM_GROUPS = [('', 'مدیریت ارتباط با مشتری', ['کنسول مدیریت ارتباط با مشتری تحت وب (۵ کاربر)', 'کاربر اضافه تا ۲۰ کاربر', 'مدیریت فرصت‌ها']),
              ('', 'خدمات پس از فروش', ['مدیریت درخواست‌ها (Ticketing)']),
              ('', 'فرم‌ساز و BPMS', ['مدیریت چرخه‌های کاری + BPMS', 'فرم‌ساز']),
              ('', 'استقرار و پشتیبانی', ['۱۵ نفرساعت استقرار پایه', '۱۵ نفرساعت استقرار تکمیلی', 'بسته نقره‌ای سال اول']),
              ('', 'اختیاری', ['اپلیکیشن موبایل (اندروید)'])]
LOM_NOTE = 'مبالغ در پیش‌فاکتور جدا آمده است.'
HOURS_BASE, HOURS_EXTRA = 15, 15
SUPPORT_LINE = 'شروع کار کاربران؛ پشتیبانی سال اول با بسته نقره‌ای.'
DEP_NOTE = '<b>ورود اطلاعات اولیه:</b> هویت‌ها با فایل اکسل در همین ساعت‌ها وارد می‌شوند. انتقال سایر داده‌ها شخصی‌سازی است و زمان و هزینه آن پس از بررسی تیم فنی اعلام می‌شود.'
# SLA page only if the customer asked for SLA. Map each customer severity to SEV-1 / SEV-2 of the lowest package that meets the
# SEV-1 response (contract-policy.md: Basic 4h, Enhanced 3h, Premium 1h); SLA is sold only next to the Gold or Platinum support plan.
SLA = [('بحرانی', 'توقف کار همه کاربران', 'SEV-1', [('پاسخ اولیه', '۲ ساعت کاری', '۱ ساعت', 'up'), ('رفع یا راه‌حل موقت', '۸ ساعت کاری', '۸ ساعت کاری', 'ok')]),
       ('عادی', 'اختلال با راه جایگزین', 'SEV-2', [('پاسخ اولیه', '۸ ساعت کاری', '۴ ساعت کاری', 'up'), ('رفع یا راه‌حل موقت', '۲ روز کاری', '۳ روز کاری', 'no')])]
SLA_PACKAGE = 'Premium'; SLA_BADGE = 'پیوست SLA سطح C، کنار بسته پشتیبانی طلایی'
SLA_WHY = ['پیوست SLA فقط کنار بسته پشتیبانی طلایی یا پلاتینیوم خریده می‌شود.']
