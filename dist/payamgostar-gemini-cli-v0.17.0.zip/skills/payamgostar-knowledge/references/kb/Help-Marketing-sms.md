# مستندات رسمی پیام‌گستر — Help-Marketing-sms

منبع: مخزن رسمی 1stco/PayamGostarDocs (commit e6143c66b174، ۱۴۰۵/۰۶/۱۴) — متن مقاله‌های help.payamgostar.com/docs. تصاویر به‌صورت پیوند `![IMG-…](</kb-assets/kb-images/…>)` (مسیر از ریشه مخزن PGSkill) آمده‌اند؛ متن داخل تصویر جست‌وجو نمی‌شود. فهرست تصاویر: `references/kb-images-index.csv`.

## پیام کوتاه
`مسیر سند: Help/Marketing/sms/sms.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/sms.md)

##### در این بخش امکان مشاهده گزارش از ارسال پیام ها، بصورت نموداری می باشد که شامل دو نمودار می باشد :

**نمودار پیام کوتاه های ارسالی در ماه های گذشته:**  بصورت خودکار سه ماه گذشته نمایش داده می شود ، که در هر کدام از این ماه ها چه تعداد پیام ارسال شده و چه تعداد به مخاطب رسیده است .

**نمودار پیام کوتاه های ارسالی در 90 روز گذشته:**  در این قسمت گزارش نموداری ارسال پیام ها در 90 روز گذشته نمایش داده می شود ، که در هر روز چه تعداد پیام ارسال شده و چه تعداد پیام رسیده به مخاطب داشتیم .

![IMG-0848](</kb-assets/kb-images/Help/Marketing/sms/advertising-sms.webp>)

[مدیریت ارسال گروهی پیامک](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/send-group/send-group.md)

[رویداد تبلیغاتی](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Advertising-event/advertising-event.md)

[خبرنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Newsletters/newsletters.md)

 [نظرسنجی](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/survey/survery.md)

[مسابقه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Competition/compertition.md)

[پاسخگوی خودکار](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Autoresponder/autoresponder.md)

[لیست پیامک‌های ارسالی](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Send-ist/send-list-new.md)

[لیست پیامک‌های دریافتی](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/resive-list/resive-list.md)

## پاسخگو خودکار
`مسیر سند: Help/Marketing/sms/Autoresponder/autoresponder.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Autoresponder/autoresponder.md)

برای ارسال خودکار اطلاعات به مخاطب مانند آدرس، شماره فکس و .... می توانید از این آیتم تبلیغات استفاده کنید.

این قابلیت به این صورت می باشد که باید گزینه و اطلاعات مورد نظر برای ارسال تعریف می شود و مخاطب با ارسال هر کدام از گزینه های مورد نظر اطلاعات مربوط به آن گزینه را دریافت می کند .

در صفحه اول، می توان با تعیین تاریخ اجرا و زدن دکمه فیلتر، لیست برنامه های اجرا شده در گذشته را مشاهده کرد. اما برای اجرای یک برنامه جدید باید بر روی دکمه "پاسخگوی جدید" در سمت راست و بالای صفحه کلیک کرده و با گذراندن چند گام ساده، برنامه را به راحتی اجرا کرد .

لطفا ابتدا [اطلاعات مشترک بین ابزارها](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/moshtarak-abzar.md) را مطالعه فرمایید و طبق گام های زیر برای ارسال گروهی جدید اقدام فرمایید.

 گام 1- [اطلاعات پاسخگو](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Autoresponder/1-avalie-khodkar/1-avalie-khodkar.md)

گام 2-  [نحوه اجرا](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Autoresponder/2-nahveejra-khodkar/2-nahveejra-pasokh-khodkar.md)

گام 3-  [دعوتنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Autoresponder/3-davatname-pasokh-khodkar/3-davatname-pasokh-khodkar.md)

گام 4-  [مخاطبین دعوتنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Autoresponder/4-mokhatab-pasokh-khodkar/4-mokhatab-pasokh-khodkar.md)

![IMG-0858](</kb-assets/kb-images/Help/Marketing/sms/Autoresponder/advertising-sendingautoanswer.webp>)

## انتخاب مخاطبان دعوتنامه پاسخگو خودکار
`مسیر سند: Help/Marketing/sms/Autoresponder/4-mokhatab-pasokh-khodkar/4-mokhatab-pasokh-khodkar.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Autoresponder/4-mokhatab-pasokh-khodkar/4-mokhatab-pasokh-khodkar.md)

##### 1. انتخاب مخاطبین:
اگر در گام قبل تصمیم به ارسال دعوتنامه گرفته باشید، در این گام باید [مخاطبان دعوتنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20se/select-Audience.md) را تعیین کنید.

برای اطلاعات بیشتر به قسمت انتخاب مخاطبان ارسال گروهی پیام کوتاه مراجعه نمایید.

این مخاطبان باید شامل پروفایل هایی باشند که شماره تلفن همراه در آن ها وجود داشته باشد .

##### 2. محدود نمودن مخاطبان:
در این قسمت با زدن تیک، مخاطبان پاسخگوی خودکار فقط افرادی هستند که در این دعوتنامه برایشان پیام می فرستید و

مخاطبان دیگر نمی توانند از پاسخگوی خودکار استفاده کنند .

![IMG-0862](</kb-assets/kb-images/Help/Marketing/sms/Autoresponder/4-mokhatab-pasokh-khodkar/advertising-sendingautoanswer-fourthstep.webp>)

## گام 1 - اطلاعات اولیه پاسخگو خودکار
`مسیر سند: Help/Marketing/sms/Autoresponder/1-avalie-khodkar/1-avalie-khodkar.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Autoresponder/1-avalie-khodkar/1-avalie-khodkar.md)

**1. عنوان/شروع ارتباط:** عنوان مورد نظر برای این برنامه باید تعریف شود  . در صورت تمایل، می توان کمپین تبلیغاتی مشخصی را به این پاسخگو خودکار متصل کرد تا تعداد پیام های ارسالی در هزینه های آن کمپین محاسبه گردد.

**2. گزینه جدید:** برای ایجاد گزینه ها باید از گزینه جدید استفاده کرد .

**3. تعیین شماره:** در این فیلد شماره گزینه ها تعریف می گردد ، که مخاطب قرار است به عنوان انتخاب خود ارسال نماید. برای مثال "1"

**4. متن گزینه:** در این قسمت، عنوان گزینه انتخاب می شود. برای مثال "شماره فکس"

**5. تعیین پاسخ های مناسب:** متن هر گزینه برای ارسال در اینجا انتخاب میشود، برای مثال "شماره فکس شرکت 02144444444 می باشد، با تشکر از  شما"

**6. ذخیره:** گزینه مورد نظر را ذخیره می کند.

**7**. در این قسمت گزینه های ساخته شده بصورت یک لیست نمایش داده می شوند.

**8. پیام پیش فرض:** می شود مشخص کرد هنگامی که مخاطب عددی بغیر از ، گزینه های تعیین شده ارسال کند ، متن تعریف شده در این قسمت  برایش ارسال شود .

![IMG-0859](</kb-assets/kb-images/Help/Marketing/sms/Autoresponder/1-avalie-khodkar/advertising-sendingautoanswer-firststep.webp>)

## گام 2 - نحوه اجرا پاسخگو خودکار
`مسیر سند: Help/Marketing/sms/Autoresponder/2-nahveejra-khodkar/2-nahveejra-pasokh-khodkar.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Autoresponder/2-nahveejra-khodkar/2-nahveejra-pasokh-khodkar.md)

**1.بازه اجرا:**  تعیین تاریخ و ساعت شروع و پایان بازه اجرا از این قسمت انجام می شود .

**2.تعیین اپراتور ارسال:** اپراتور مورد نظر برای ارسال،برای مثال پرتال اول ، رایان و ...  و در نهایت خط مورد استفاده باید انتخاب شود .

**بررسی قابل دسترس بودن خط:**  در این نوع از ارسال داشتن خط با قابلیت دریافت الزامی است، تا از طریق آن بتوان نظر مخاطبان را در بازه زمانی اجرای کمپین دریافت نمود ،

 در بازه اجرا خط مورد نظر نباید در برنامه دیگری مانند مسابقه و پاسخگوی خودکار و .... استفاده شود .  با استفاده از این کلید می شود بررسی کرد که خط مورد نظر مشغول است یا خیر .

![IMG-0860](</kb-assets/kb-images/Help/Marketing/sms/Autoresponder/2-nahveejra-khodkar/advertising-sendingautoanswer-secondstep.webp>)

## گام 3 - دعوتنامه پاسخگو خودکار
`مسیر سند: Help/Marketing/sms/Autoresponder/3-davatname-pasokh-khodkar/3-davatname-pasokh-khodkar.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Autoresponder/3-davatname-pasokh-khodkar/3-davatname-pasokh-khodkar.md)

در این گام در صورت نیاز می توانید برای آغاز به کار پاسخگوی خودکار دعوتنامه تعیین و به مخاطبان دلخواه ارسال کنید تا از امکانات آن مطلع گردند.

در بالای کادر[ متن هوشمند ، ](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/Parameters/MessageParameters.md)تیک ارسال دعوتنامه را فعال کنید تا امکان استفاده از متن هوشمند (به عنوان یکی از ویژگی های خاص پیام گستر) در این گام برای شما فراهم شود. با فعال شدن متن، به طور پیش فرض عنوان و محتوای پاسخگو نمایان می شود که قابل ویرایش است.

![IMG-0861](</kb-assets/kb-images/Help/Marketing/sms/Autoresponder/3-davatname-pasokh-khodkar/advertising-sendingautoanswer-thirdstep.webp>)

## صفحه‌ی اصلی مسابقه
`مسیر سند: Help/Marketing/sms/Competition/compertition.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Competition/compertition.md)

با استفاده از این قابلیت می توان مسابقه ای ایجاد کردکه گزینه های مورد نظر را تعریف و گزینه صحیح و تعداد برندگان را مشخص نمود  و همچنین امکان انتخاب برنده  از بین پاسخ های صحیح وجود دارد .

در صفحه اول، می توان با تعیین تاریخ اجرا،ایجاد کننده، نام برنامهو همچنین انتخاب وضعیت قرعخ کشی  و زدن دکمه فیلتر ، لیست برنامه های اجرا شده در گذشته را مشاهده کرد. اما برای اجرای یک برنامه جدید باید بر روی دکمه " مسابقه جدید" در سمت راست و بالای صفحه کلیک کرده و با گذراندن چند گام ساده، برنامه را به راحتی اجرا کرد.

لطفا ابتدا [اطلاعات مشترک بین ابزارها](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/moshtarak-abzar.md) را مطالعه فرمایید و طبق گام های زیر برای ارسال گروهی جدید اقدام فرمایید .

 گام 1- [اطلاعات مسابقه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Competition/1-avalie-mosabeghe/1-avalie-mosabeghe.md)

گام 2-  [نحوه اجرا](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Competition/2-nahveejra-mosabeghe/2-nahveejra-mosabeghe.md)

گام 3-  [تاییدیه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Competition/3-payamtaid-mosabeghe/3-payamtaid-mosabeghe.md)

گام 4-  [دعوتنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Competition/4-davatname-mosabeghe/4-davatname-mosabeghe.md)

گام 5-  [مخاطبین دعوتنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Competition/5-entekhabmokhatab-mosabeghe/5-mokhatab-mosabeghe.md)

![IMG-0863](</kb-assets/kb-images/Help/Marketing/sms/Competition/advertising-sendingcompetitionsms.webp>)

## گام 1 -اطلاعات اولیه مسابقه
`مسیر سند: Help/Marketing/sms/Competition/1-avalie-mosabeghe/1-avalie-mosabeghe.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Competition/1-avalie-mosabeghe/1-avalie-mosabeghe.md)

**1. شروع ارتباط با مشتری:** در صورت تمایل، می توان کمپین تبلیغاتی مشخصی را به این نظرسنجی متصل کرد تا تعداد پیام های ارسالی در هزینه های آن کمپین محاسبه گردد.

**2. تعیین یک عنوان:** یک عنوان برای مسابقه انتخاب کنید.

**3. تعیین سوال مسابقه:** سوال مسابقه در این فیلد باید مشخص شود.

**4. اضافه کردن:** ابتدا جهت تعریف گزینه ها، دکمه اضافه کردن را بفشارید تا امکان ایجاد گزینه ها فراهم شود و همچنن : در هر مرحله بازدن دکمه اضافه کردن، یک گزینه دیگر می توانید تعریف نمایید.

**5. گزینه‌ها:** در این قسمت، شماره گزینه ها را باید تعیین کنید، دقت شود که مخاطبان از شماره گزینه ها بعنوان متن ارسالی جهت شرکت در نظرسنجی استفاده خواهند کرد و همچنین متن گزینه ها باید تعریف شود .

**6. حداکثر تعداد شرکت کنندگان:**  با استفاده از این گزینه امکان محدود کردن تعداد مخاطبان وجود دارد

**7. تعداد برندگان:** در این قسمت، می توانید تعداد برندگان از بین شرکت کنندگان را تعیین کنید و حتی تعیین کنید که برندگان از بین پاسخ های صحیح انتخاب شود .

**8**. با زدن گام 2 به مرحله بعد خواهید رفت.

![IMG-0864](</kb-assets/kb-images/Help/Marketing/sms/Competition/1-avalie-mosabeghe/advertising-sendingcompetitionsms-firststep.webp>)

## گام 4 - دعوتنامه مسابقه
`مسیر سند: Help/Marketing/sms/Competition/4-davatname-mosabeghe/4-davatname-mosabeghe.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Competition/4-davatname-mosabeghe/4-davatname-mosabeghe.md)

در این گام می توان برای مخاطبان، متن دعوت به شرکت در مسابقه را ارسال نمود .

در بالای کادر متن هوشمند، تیک ارسال دعوتنامه را فعال کنید تا امکان استفاده از متن هوشمند (به عنوان یکی از ویژگی های خاص پیام گستر) در این گام برای شما فراهم شود.

> نکته: در صورتی که ارسال دعتونامه را در این قسمت فعال کرده باشید، این برنامه حداقل باید یک مخاطب داشته باشد تا اجرا شود.

![IMG-0867](</kb-assets/kb-images/Help/Marketing/sms/Competition/4-davatname-mosabeghe/advertising-sendingcompetitionsms-fourthstep.webp>)

## گام 3 - پیام تاییدیه مسابقه
`مسیر سند: Help/Marketing/sms/Competition/3-payamtaid-mosabeghe/3-payamtaid-mosabeghe.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Competition/3-payamtaid-mosabeghe/3-payamtaid-mosabeghe.md)

در این گام می توان برای شرکت کنندگان، پیام تاییدیه شرکت در مسابقه را ارسال نمود.

در بالای کادر، تیک ارسال پیام تاییدیه را فعال کنید تا امکان نوشتن متن در این گام برای شما فراهم شود. می توانید به شرکت کنندگان اطمینان دهید که پیام آنها رادریافت کرده اید .

![IMG-0866](</kb-assets/kb-images/Help/Marketing/sms/Competition/3-payamtaid-mosabeghe/advertising-sendingcompetitionsms-thirddstep.webp>)

## گام 2 - نحوه اجرا مسابقه
`مسیر سند: Help/Marketing/sms/Competition/2-nahveejra-mosabeghe/2-nahveejra-mosabeghe.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Competition/2-nahveejra-mosabeghe/2-nahveejra-mosabeghe.md)

**1. بازه اجرا:**  تاریخ و ساعت  شروع و پایان بازه اجرا را تعیین کنید.

**2. تعیین اپراتور ارسال:** اپراتور مورد نظر برای ارسال،برای مثال پرتال اول ، رایان و ...  و در نهایت خط مورد استفاده باید انتخاب شود .

**بررسی قابل دسترس بودن خط:**  در این نوع از ارسال داشتن خط با قابلیت دریافت الزامی است، تا از طریق آن بتوان نظر مخاطبان را در بازه زمانی اجرای کمپین دریافت نمود ،

 در بازه اجرا خط مورد نظر نباید در برنامه دیگری مانند مسابقه و پاسخگوی خودکار و .... استفاده شود .  با استفاده از این کلید می شود بررسی کرد که خط مورد نظر مشغول است یا خیر

![IMG-0865](</kb-assets/kb-images/Help/Marketing/sms/Competition/2-nahveejra-mosabeghe/advertising-sendingcompetitionsms-secondstep.webp>)

## گام 5 - انتخاب مخاطبان مسابقه
`مسیر سند: Help/Marketing/sms/Competition/5-entekhabmokhatab-mosabeghe/5-mokhatab-mosabeghe.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Competition/5-entekhabmokhatab-mosabeghe/5-mokhatab-mosabeghe.md)

اگر در گام قبل تصمیم به ارسال دعوتنامه گرفته باشید، در این گام باید مخاطبان دعوتنامه را تعیین کنید .

برای اطلاعات بیشتر به قسمت[ انتخاب مخاطبان](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20se/select-Audience.md) ارسال گروهی پیام کوتاه مراجعه نمایید.

این مخاطبان باید شامل پروفایل هایی باشند که شماره تلفن همراه در آن ها وجود داشته باشد

![IMG-0868](</kb-assets/kb-images/Help/Marketing/sms/Competition/5-entekhabmokhatab-mosabeghe/advertising-sendingcompetitionsms-fifthstep.webp>)

با فعال کردن این گزینه فقط مخاطبانی که دعوت نامه را دریافت می کنند می توانند در مسابقه شرکت کنند.

## نظرسنجی
`مسیر سند: Help/Marketing/sms/survey/survery.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/survey/survery.md)

برای آگاهی از نظرات مخاطبان خود در جهت بهبود برنامه های بازاریابی ، فروش و ... می توانید از نظرسنجی استفاده کنید. در صفحه اول، می توان با تعیین تاریخ اجرا،ایجاد کننده و نام برنامه  و زدن دکمه فیلتر، لیست برنامه های اجرا شده در گذشته را مشاهده کرد. اما برای اجرای یک برنامه جدید باید بر روی دکمه  "نظرسنجی جدید" در سمت راست و بالای صفحه کلیک کرده و با گذراندن چند گام ساده، برنامه را به راحتی اجرا کرد

لطفاابتدا [اطلاعات مشترک بین ابزارها](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/moshtarak-abzar.md) را مطالعه فرمایید و طبق گام های زیر برای ارسال گروهی جدید اقدام فرمایید.

 گام 1- [اطلاعات نظرسنجی](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/survey/1-avalie-nazarsanji/avalie-nazarsanji.md)

گام 2-  [نحوه اجرا](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/survey/2-nahveajra-nazaesanji/2-nahve-ejra-nazarsanji.md)

گام 3-  [تاییدیه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/survey/3-taid-nazarsanji/3-taid-nazarsanji.md)

گام 4-  [دعوتنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/survey/4-davatname-nazarsanji/untitled.md)

گام 5-  [مخاطبین دعوتنامه](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/survey/5-mokhatab-davatname/5-entekhabmokhatab-nazarsanji.md)

![IMG-0882](</kb-assets/kb-images/Help/Marketing/sms/survey/advertising-sendingqustionary-firststep.webp>)

## گام 4 - دعوتنامه نظرسنجی
`مسیر سند: Help/Marketing/sms/survey/4-davatname-nazarsanji/untitled.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/survey/4-davatname-nazarsanji/untitled.md)

در این گام می توان برای مخاطبان، متن دعوت به شرکت در نظرسنجی را ارسال نمود .

در بالای کادر متن هوشمند، تیک ارسال دعوتنامه را فعال کنید تا امکان استفاده از متن هوشمند (به عنوان یکی از ویژگی های خاص پیام گستر) در این گام برای شما فراهم شود .

![IMG-0886](</kb-assets/kb-images/Help/Marketing/sms/survey/4-davatname-nazarsanji/advertising-nazarsanji-5.webp>)

## گام 3 - پیام تایید نظرسنجی
`مسیر سند: Help/Marketing/sms/survey/3-taid-nazarsanji/3-taid-nazarsanji.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/survey/3-taid-nazarsanji/3-taid-nazarsanji.md)

در این گام می توان برای شرکت کنندگان، پیام تاییدیه شرکت در نظرسنجی را ارسال نمود .

در بالای کادر، تیک ارسال پیام تاییدیه را فعال کنید تا امکان نوشتن متن در این گام برای شما فراهم شود. می توانید به شرکت کنندگان اطمینان دهید که پیام آنها رادریافت کرده اید

![IMG-0885](</kb-assets/kb-images/Help/Marketing/sms/survey/3-taid-nazarsanji/advertising-nazarsanji-4.webp>)

## گام 2 - نحوه اجرا نظرسنجی
`مسیر سند: Help/Marketing/sms/survey/2-nahveajra-nazaesanji/2-nahve-ejra-nazarsanji.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/survey/2-nahveajra-nazaesanji/2-nahve-ejra-nazarsanji.md)

**1. بازه اجرا:** تاریخ و ساعت شروع و پایان برنامه تعیین  گردد.

**2. تعیین اپراتور ارسال:** اپراتور مورد نظر برای ارسال،برای مثال پرتال اول ، رایان و ...  و در نهایت خط مورد استفاده باید انتخاب شود .

**3. بررسی قابل دسترس بودن خط:**  در این نوع از ارسال داشتن خط با قابلیت دریافت الزامی است، تا از طریق آن بتوان نظر مخاطبان را در بازه زمانی اجرای کمپین دریافت نمود ،

 در بازه اجرا خط مورد نظر نباید در برنامه دیگری مانند مسابقه و پاسخگوی خودکار و .... استفاده شود .  با استفاده از این کلید می شود بررسی کرد که خط مورد نظر مشغول است یا خیر .

با کلیک بر روی گام 3 وارد مرحله بعدی خواهیم شدیم.

![IMG-0884](</kb-assets/kb-images/Help/Marketing/sms/survey/2-nahveajra-nazaesanji/advertisingNAZARSANJI.webp>)

## گام 5 - انتخاب مخاطبان دعوتنامه نظرسنجی
`مسیر سند: Help/Marketing/sms/survey/5-mokhatab-davatname/5-entekhabmokhatab-nazarsanji.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/survey/5-mokhatab-davatname/5-entekhabmokhatab-nazarsanji.md)

اگر در گام 4 تصمیم به ارسال دعوتنامه گرفته باشید، در این گام باید مخاطبان دعوتنامه را تعیین کنید.

در قسمت انتخاب مخاطبان توضیح داده شده است.

> نکته: در صورتی که ارسال دعتونامه را در این قسمت فعال کرده باشید، این برنامه حداقل باید یک مخاطب داشته باشد تا اجرا شود.

![IMG-0887](</kb-assets/kb-images/Help/Marketing/sms/survey/5-mokhatab-davatname/advertising-sendingnewssms-thirdstep.webp>)

## گام1 - اطلاعات اولیه نظر سنجی
`مسیر سند: Help/Marketing/sms/survey/1-avalie-nazarsanji/avalie-nazarsanji.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/survey/1-avalie-nazarsanji/avalie-nazarsanji.md)

**1. شروع ارتباط با مشتری و عنوان:** در صورت تمایل، می توان کمپین تبلیغاتی مشخصی را به این نظرسنجی متصل کرد تا تعداد پیام های ارسالی در هزینه های آن کمپین محاسبه گردد و یک عنوان برای نظرسنجی تعیین کرد.

**2. تعیین سوال نظر سنجی:** سوال مورد نظر برای نظر سنجی را در این کادر ثبت می نمایید.

**3. تعیین گزینه‌ها:** در این قسمت، شماره گزینه ها را باید تعیین کنید، دقت شود که مخاطبان از شماره گزینه ها بعنوان متن ارسالی جهت شرکت در نظرسنجی استفاده خواهند کرد.

**4. متن گزینه:** عنوان هر گزینه جهت ارسال نظر از سمت مخاطبان در این قسمت تعیین می شود.

**5. اضافه کردن:** ابتدا جهت تعریف گزینه ها، دکمه اضافه کردن را بفشارید تا امکان ایجاد گزینه ها فراهم شود و همچنن : در هر مرحله بازدن دکمه اضافه کردن، یک گزینه دیگر می توانید تعریف نمایید.

**6. حداکثر تعداد شرکت کنندگان:** با استفاده از این گزینه امکان محدود کردن تعداد مخاطبان وجود دارد

با کلیک بر روی گام 2 وارد مرحله بعد می شویم.

![IMG-0883](</kb-assets/kb-images/Help/Marketing/sms/survey/1-avalie-nazarsanji/advertising-sendingqustionary-secondstep.webp>)

## رویداد تبلیغاتی پیامک
`مسیر سند: Help/Marketing/sms/Advertising-event/advertising-event.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Advertising-event/advertising-event.md)

برای ارسال پیام هوشمند در زمانبندهای دقیق و پیشرفته، می توانید از رویداد تبلیغاتی استفاده کنید.

با استفاده از رویداد می توان زمانبندی های مشخصی برای ارسال پیام های متفاوت در نظر گرفت ، برای مثال می توان برای تاریخ هایی که در مدیریت اعیاد و مناسبت ها تعریف شده است پیام های متفاوتی تنظیم کرد تا در همان تاریخ ها برای مخاطبان انتخاب شده ،  ارسال شود .

 در صفحه اول، می توان با تعیین تاریخ اجرا ، ایجاد کننده رویداد و یا عنوان تعریف شده برای رویداد و زدن دکمه فیلتر، لیست برنامه های اجرا شده در گذشته را مشاهده کرد. اما برای اجرای یک برنامه جدید باید بر روی دکمه " رویداد جدید " در سمت راست و بالای صفحه کلیک کرده و با گذراندن چند گام ساده، برنامه را به راحتی اجرا کرد

 گام 1- [اطلاعات رویداد](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/email/Advertising-event-email/1-avalie-roydad-email/1-avalie-roydad-email.md)

گام 2-  زمان اجرا

گام 3-  تنظیم متن

گام 4-  انتخاب مخاطبان

![IMG-0849](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/advertising-sendingeventsms.webp>)

## گام 3 -  محتوای پیام رویداد تبلیغاتی پیامک
`مسیر سند: Help/Marketing/sms/Advertising-event/3-tanzim-matn/tanzim-matn.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Advertising-event/3-tanzim-matn/tanzim-matn.md)

  لطفا ابتدا به [گام دوم - محتوای پیام](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20do/gam-do.md) در اطلاعات مشترک ابزارها مراجعه کنید.

 **1. حالت رویداد:** در حالت تک متنی برای کلیه تاریخ های انتخابی فقط یک متن ارسال می شود و در حالت چند متنی می توانید برای هر تاریخ یک متن مشخص را ویرایش نمایید.

![IMG-0854](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/3-tanzim-matn/advertising-roydad-4-sms.webp>)

 **1.حالت پیام ارسالی:**  در حالت تک متنی برای کلیه تاریخ های انتخابی فقط یک متن ارسال می شود و در حالت چند متنی می توانید برای هر تاریخ یک متن مشخص تنظیم نمایید .

> نکته: انتخاب حالت چند متنی فقط زمانی در دسترس می باشد که زمان اجرا روی تاریخ های انتخابی باشد .

هنگامی که زمان اجرا روی مناسبت های انتخابی باشد حالت چند متنی قابل انتخاب نیست اما میشود در کنار کادر متنی، هر تاریخ را تک به تک انتخاب نمود و متن مربوط به آن را تنظیم کرد .

**2. لیست تاریخ‌ها:** تاریخ های انتخاب شده را نمایش می دهد و با کلیک بر روی هرکدام می توانید پیامی بخصوصی که قرار است در آن تاریخ ارسال شود را مشخص نمایید.

**3. افزودن از لیست اعیاد:** میتوانید یکی از اعیادی که در بازه زمانی شروع و پایان انتخاب شده قرار گرفته اند را انتخاب کنید.

![IMG-0855](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/3-tanzim-matn/Step3p2.webp>)

**4. افزودن تاریخ دستی:**  میتوانید تاریخ های مورد نظر را بصورت دستی وارد لیست تاریخ ها کنید.

![IMG-0856](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/3-tanzim-matn/advertisingSending.webp>)

**5. لیست پارامترها:** از بین پارامترهای هوشمند، میتوانید پارامترهای متغیر در هر مخاطب را انتخاب و با دوبار کلیک آن را به متن پیام اضافه نمایید.

**6. متن پیام:** میتوانید متن پیام رویداد را در اینجا بنویسید.

## گام 4 -  مدیریت مخاطبان رویداد تبلیغاتی پیامک
`مسیر سند: Help/Marketing/sms/Advertising-event/4-entekhab-mokhatab/entekhab-mokhatab.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Advertising-event/4-entekhab-mokhatab/entekhab-mokhatab.md)

برای استفاده از این بخش به لینک ([ انتخاب مخاطبان](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20se/select-Audience.md) ) مراجعه نمایید.

این مخاطبان باید شامل پروفایل هایی باشند که شماره تلفن همراه در آن ها وجود داشته باشد .

![IMG-0857](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/4-entekhab-mokhatab/advertising-sendingeventsms-fourthstep.webp>)

## گام 2 -  زمان اجرا رویداد تبلیغاتی پیامک
`مسیر سند: Help/Marketing/sms/Advertising-event/2-zaman-bandi/zaman-bandi.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Advertising-event/2-zaman-bandi/zaman-bandi.md)

**در این گام، سه نوع زمان بندی برای اجرای برنامه پیشنهاد می شود:**

![IMG-0851: صفحه زمان اجرای رویداد تبلیغاتی پیامکی](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/Images/Timing-for-Event-marketing-sms.webp>)

1. **زمان‌بندی دوره‌ای**

   با انتخاب گزینه‌های روزانه، هفتگی، ماهانه و سالیانه می‌توانید نحوه ارسال پیام را تعیین کنید. با انتخاب هر کدام از گزینه‌ها به دو صورت امکان تعیین بازه زمانی وجود دارد:

   - زمان **شروع** و **پایان** رویداد را تعیین کنید.
   - زمان **شروع** و **دفعات ارسال پیام** را تعیین کنید.
2. **تاریخ تأسیس/تولد**

   با انتخاب این گزینه رویداد پیامکی شما برای هویت‌های حقوقی براساس **تاریخ تاسیس** و برای هویت‌های حقیقی، براساس **تاریخ تولد** که در پروفایل آن‌ها وارد کرده‌اید، اجرا خواهد شد.
3. **کل مناسبت‌ها در بازه تعیین شده**

   تمامی مناسبت‌هایی که در بخش اعیاد و مناسبت‌ها تعیین کرده‌اید را در این قسمت نمایش داده و این برنامه را برای همه‌ی آن مناسبت‌ها اجرا می‌کند.

![IMG-0852: کل مناسبت‌ها برای زمان‌بندی رویداد تبلیغاتی پیامکی](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/Images/all-Events.webp>)

> **نکته**

> اگر در [مدیریت اعیاد و مناسبت‌ها](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Basic-Information/Holiday-management-and-occasions/Holiday-management-and-occasions.md) برای مناسبت‌های تعریف شده پیامی تنظیم شده باشد ، زمانی که تاریخ مورد نظر انتخاب شود برای ارسال رویداد، متن پیام تعریف شده نمایش داده خواهد شد که می‌توانید متن آن را ویرایش کرده و در برنامه استفاده نمایید.

4. **مناسبت‌های انتخابی**

   در این حالت لیست تمامی مناسبت‌هایی که در بخش [مدیریت اعیاد و مناسبت‌ها](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Basic-Information/Holiday-management-and-occasions/Holiday-management-and-occasions.md) تعیین کرده‌اید را نمایش داده ولی چک باکس همه‌ی آن‌ها انتخاب شده نیست و می‌توانید هرکدام از آن مناسبت‌ها را برای رویداد خود انتخاب نمایید.

![IMG-0853: مناسبت‌های انتخابی در رویداد پیامکی](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/Images/Event-Optional.webp>)

5. **تاریخ‌های انتخابی**

   با انتخاب این گزینه، بدون هیچ محدودیتی در این مرحله می‌توانید ساعت و تاریخ شروع و پایان رویداد را مشخص کنید (دیگر در این‌جا تعداد اجرا معنایی ندارد)

   از طرفی در مرحله سوم -محتوای پیام- گزینه **چند متنی** برای شما فعال شده که می‌توانید برای رویداد خود **تاریخ‌های مختلف** تعیین کرده و یا از **لیست مناسبت‌ها** یک یا چند مناسبت را انتخاب نمایید.

> **نکته**

>  در ارسال گروهی **مدیریت رویداد** و **خبرنامه** در صورت اینکه در روز یکبار لیست ارسال تشکیل و پیام ارسال شده باشد و بخواهید تنظیمات آن را ویرایش کنید، در ان روز مجددا ارسال نمیشود و این تغییرات برای ارسال فردا اعمال میشود .اما اگر قبل از تشکیل لیست ارسال یعنی قبل از اجرا و ساعت آن رویداد و خبرنامه، تغییرات اعمال می‌شود.

## گام 1 - اطلاعات  پیام رویداد تبلیغاتی پیامک
`مسیر سند: Help/Marketing/sms/Advertising-event/1-avalie/avalie-roydad.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Advertising-event/1-avalie/avalie-roydad.md)

  به گام اول - اطلاعات پیام در[ اطلاعات مشترک ابزارها](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20yk/gam-yk.md) مراجعه کنید.

![IMG-0850](</kb-assets/kb-images/Help/Marketing/sms/Advertising-event/1-avalie/advertising-sendingeventsms-firststep.webp>)

 **1-** دراین فیلد عنوان رویداد مشخص می شود
 **2-** اپراتور ارسال و رسانه ارسال از طریق این دو فیلد مشخص می شود
 **3-** جهت ادامه، باید به مرحله دوم - زمان اجرا بروید

## خبرنامه
`مسیر سند: Help/Marketing/sms/Newsletters/newsletters.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Newsletters/newsletters.md)

برای ارسال پیام های هوشمند مختلف در زمان های مختلف با قابلیت عضویت و لغو عضویت برای مخاطبان از خبرنامه استفاده کنید.

با استفاده از این قابلیت این امکان فراهم می شود تا در تاریخ های مورد نظر پیام های مختلفی را برای مخاطبان خود ارسال کنید ، که این مورد قابلیت عضویت افراد  برای دریافت خبرنامه های ما و همچنین لغو عضویت مخاطبان را دارد . یعنی می شود برنامه ای تعریف کرد و به مخاطبان اجازه عضو شدن برای دریافت پیام ها و لغو عضویتی که داشتن برای عدم دریافت پیام ها داشته باشند .

در صفحه اول، می توان با تعیین تاریخ اجرا، کاربر ایجاد کننده برنامه،نام برنامه تعریف شده و براساس قابلیت عضویت و لغو عضویت و زدن دکمه فیلتر، لیست برنامه های اجرا شده در گذشته را مشاهده کرد. اما برای اجرای یک برنامه جدید باید بر روی دکمه "خبرنامه جدید" در سمت راست و بالای صفحه کلیک کرده و بالای صفحه کلیک کرده و با گذراندن چند گام ساده، برنامه را به راحتی اجرا نمایید.

لطفا ابتدا [اطلاعات مشترک بین ابزارها](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/moshtarak-abzar.md) را مطالعه فرمایید و طبق گام های زیر برای ارسال گروهی جدید اقدام فرمایید.

 گام 1- اطلاعات خبرنامه

گام 2-  تنظیم متن

گام 3-  انتخاب مخاطبان

## گام 3 -  مدیریت مخاطبان خبرنامه پیامک
`مسیر سند: Help/Marketing/sms/Newsletters/3-entekhab-mokhatab/entekhab-mokhatab.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Newsletters/3-entekhab-mokhatab/entekhab-mokhatab.md)

در قسمت انتخاب مخاطبان ارسال گروهی پیام کوتاه توضیح داده شده است.

این مخاطبان باید شامل پروفایل هایی باشند که شماره تلفن همراه در آن ها وجود داشته باشد .

در این مرحله پس از انتخاب مخاطبان از بانک های اطلاعاتی، یک لیست از مخاطبان هدف ساخته می شود که با زدن دکمه ثبت، خبرنامه ایجاد و برنامه ی آن شروع به کار میکند.

![IMG-0871](</kb-assets/kb-images/Help/Marketing/sms/Newsletters/3-entekhab-mokhatab/advertising-sendingnewssms-thirdstep.webp>)

>   نکته:  با زدن دکمه سیستم CRM میتوانید مخاطبان هدف خود را از هویت هایی که قبلا برای آن ها آیتم crm ثبت شده است انتخاب کنید .

## گام 2 - محتوای پیام خبرنامه پیامک
`مسیر سند: Help/Marketing/sms/Newsletters/2-tanzim-matn/tanzim-matn-khabar.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Newsletters/2-tanzim-matn/tanzim-matn-khabar.md)

در این گام می توانید متن مورد نظر برای ارسال را وارد کنید. ابتدا از روی تقویم و یا[  لیست مناسبت ها ](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Basic-Information/Holiday-management-and-occasions/Holiday-management-and-occasions.md)، یک و یا چند تاریخ را مشخص کنید.

لطفا به قسمت  گام دوم -[ محتوای پیام ](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20do/gam-do.md) در اطلاعات مشترک ابزارها  مراجعه کنید.

برای اطلاع در خصوص انتخاب تاریخ ها به [گام 3- تنظیم متن رویداد تبلیغاتی](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/sms/Advertising-event/3-tanzim-matn/tanzim-matn.md) مراجعه کنید.

در ابتدا تاریخ پیام ها و سپس متن پیام را می نویسیم و در نهایت با کلیک بر روی دکمه گام سوم وارد مرحله نهایی می شویم.

![IMG-0870](</kb-assets/kb-images/Help/Marketing/sms/Newsletters/2-tanzim-matn/advertising-sendingnewssms-secondstep.webp>)

## گام 1 -  اطلاعات پیام خبرنامه پیامک
`مسیر سند: Help/Marketing/sms/Newsletters/1-avalie/avalie-khabar.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Newsletters/1-avalie/avalie-khabar.md)

![IMG-0869](</kb-assets/kb-images/Help/Marketing/sms/Newsletters/1-avalie/advertising-khabarnameh-2.webp>)

**1. شروع ارتباط با مشتریان:** در صورت تمایل، می توان کمپین تبلیغاتی مشخصی را به این خبرنامه متصل کرد تا تعداد پیام های ارسالی در هزینه های آن کمپین محاسبه گردد.

**2. عنوان خبرنامه:** عنوان خبرنامه در این فیلد مشخص می شود.

**3و4.** دارای قابلیت عضویت و لغو عضویت: می توانید کد های عضویت و لغو عضویت تعریف کنید تا مخاطبان با ارسال این کدها، به ترتیب عضویت و لغو عضویت خود را نسبت به خبرنامه اعمال کنند.

**5. تاریخ شروع:** تاریخ شروع ارسال خبرنامه را تعیین کنید.

**6. تاریخ پایان:** تاریخ پایان ارسال روزانه خبرنامه ها را تعیین کنید.

**7. ساعت ارسال:** ساعت ارسال پیام را در این فیلد مشخص نمایید.

**8. اپراتور ارسال:** اپراتور ارسال پیام خبرنامه را در این فیلد باید انتخاب نمایید.

**9. شماره خط:** پس از انتخاب اپراتور ارسال، خطی که مایلین از آن خبرنامه ارسال شود مشخص کنید.

> نکته: در صورتی که امکان عضویت در خبرنامه فعال باشد، باید خط مورد نظر در دسترس باشد، یعنی برنامه دیگری (مسابقه، نظر سنجی و ...) بر روی آن خط در بازه اجرای این برنامه فعال نباشد.

**10**. جهت رفتن به مرحله بعد، روی گام 2 کلیک نمایید.

## لیست پیام‌های ارسالی
`مسیر سند: Help/Marketing/sms/Send-ist/Send-list.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Send-ist/Send-list.md)

می توان تمام پیام هایی که در قالب برنامه های مختلف به مخاطبان ارسال شده یا در حال ارسال است مشاهده نمود. می توان نمایش این پیام ها را بر اساس پارامترهای مختلفی از قبیل خطی که برای ارسال پیام استفاده شده است یا تاریخ ارسال یا وضعیت پیام محدود نمود. همچنین می توان وضعیت ارسال، تحویل پیام ها را مشاهده نمود. در صورتی که برنامه ای که اجرا نموده اید نظرسنجی، مسابقه و یا پاسخگو باشد اگر پیامی به شما ارسال شده باشد در قسمت دنبال شده می توانید آن را مشاهده نمایید.

> نکته: برای اطلاعات بیشتر در خصوص لیست ارسال ها به قسمت اطلاعات [مشترک لیست ارسال پیام ](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/moshtarak-abzar.md)مراجعه کنید.

![IMG-0872](</kb-assets/kb-images/Help/Marketing/sms/Send-ist/advertising-smssendinglist.webp>)

## اطلاعات مشترک لیست ارسال پیام
`مسیر سند: Help/Marketing/sms/Send-ist/moshtarake-liste-ersal.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Send-ist/moshtarake-liste-ersal.md)

اطلاعات مشترک لیست ارسال پیام

![IMG-0873](</kb-assets/kb-images/Help/Marketing/sms/Send-ist/connections-samesettings-1.webp>)

**1. وضعیت ارسال:** انواع وضعیت ارسال ها به شرح ذیل می باشد:

> A. در صف ارسال: پیام به درستی در صف ارسال قرار گرفته و در حال است.
>
> B. ارسال شده به مرکز: پیام به درستی به مرکز ارسال شده است.
>
> C. ارسال شده به مخاطب: مخاطب پیام را به درستی دریافت کرده است.
>
> D.ارسال ناموفق: مخاطب پیام را دریافت نکرده است.
>
> E. مشکوک به ارسال شده به مرکز: مشکوک به ارسال شده و یا ارسال دوباره به دلایل زیر خواهد بود.
>
> الف. درست نبودن نام کاربری و رمز عبور پرتال اول
>
>     ب. مسدود بودن نام کاربری پرتال اول به دلیل رمز عبور اشتباه
>
>     پ. موجودی ناکافی (شارژ نام کاربری)
>
>     ت. مورد تایید نبودن مدارک هویتی
>
> F. ارسال دوباره: نشان دهنده تلاش مجدد برای ارسال است که دلایل این حالت همانند وضعیت مشکوک به ارسال شده به مرکز است.
>
> * * *

**2. از تاریخ/تا تاریخ:** می توانید ابتدا و انتهای بازه زمانی ارسال را مشخص کنید.

**3**. دریافت آخرین وضعیت پیام ها از مرکز: با فعال کردن این گزینه، کلید فیلتر علاوه بر اعمال فیلترهای تعیین شده، آخرین وضعیت پیام ها را از سرور دریافت خواهد کرد.

**4. به روز رسانی لیست:** با استفاده از این گزینه می توانید بر حسب ثانیه تعیین کنید که این لیست ارسال ها هر چند ثانیه یکبار به روز رسانی گردد.

**5. محتوای پیام:** با استفاده از این گزینه می توانید محتوای پیام ارسال شده را مشاهده کنید.

**6. حذف:** می توانید سابقه پیام ارسال شده را حذف کنید، کافی است پیام های مورد نظر را با تیک انتخاب و سپس دکمه حذف را کلیک نمایید.

**7. فرستادن به اکسل:** می توانید لیست ارسال های انتخاب شده را در قالب فایل اکسل دریافت کنید.

**وضعیت تحویل:** نامشخص-تحویل داده شده - ناموفق

## لیست پیامک‌های ارسالی  یک برنامه تبلیغاتی:
`مسیر سند: Help/Marketing/sms/Send-ist/send-list-new.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/Send-ist/send-list-new.md)

در لیست ارسال امکان مشاهده پیام های ارسالی به همراه زمان ارسال ، وضعیت ارسال و تحویل و محتوای پیام ارسال شده است .

 در برنامه های دوطرفه مانند پاسخگو، مسابقه، نظرسنجی که علاوه بر ارسال پیام، قابلیت دریافت پیام را نیز دارا هستند با تغییر لیست ارسال به لیست دریافت، امکان مشاهده پیام هایی که از سمت مشتریان و مخاطبان برای پاسخ به این برنامه ارسال شده است وجود دارد .

برای مشاهده لیست ارسال و یا لیست دریافت ، کاربر نیاز به مجوز مشاهده ليست پيام هاي ارسالي  دريافتي دارد .

![IMG-0874](</kb-assets/kb-images/Help/Marketing/sms/Send-ist/6.webp>)

**1. وضعیت ارسال:**  انواع وضعیت ارسال ها به شرح ذیل می باشد

**A . در صف ارسال:** پیام به درستی در صف ارسال قرار گرفته و در حال ارسال است.

**B . ارسال شده به مرکز:** پیام به درستی به پنل مرکز  ارسال شده است.

**C . ارسال شده به مخاطب:** مخاطب پیام را به درستی دریافت کرده است.

**D . ارسال ناموفق:** مخاطب پیام را دریافت نکرده است.

**E . مشکوک به ارسال شده به مرکز:** مشکوک به ارسال شده و یا ارسال دوباره به دلایل زیر خواهد بود.

**الف.** درست نبودن نام کاربری و رمز عبور پرتال اول مورد استفاده

**ب.** مسدود بودن نام کاربری پرتال اول به دلیل رمز عبور اشتباه

**پ.** موجودی ناکافی (شارژ نام کاربری)

**ت.** مورد تایید نبودن مدارک هویتی

**F . ارسال دوباره:** نشان دهنده تلاش مجدد برای ارسال است که دلایل این حالت همانند وضعیت مشکوک به ارسال شده به مرکز است.

**2. از تاریخ/تا تاریخ:** می توانید ابتدا و انتهای بازه زمانی ارسال را مشخص کنید

**3. دریافت آخرین وضعیت پیام ها از مرکز:**  با فعال کردن این گزینه، کلید فیلتر علاوه بر اعمال فیلترهای تعیین شده، آخرین وضعیت ارسال و تحویل  پیام ها را از سرور دریافت خواهد کرد.

**4. به روز رسانی لیست:** با استفاده از این گزینه می توانید بر حسب ثانیه تعیین کنید که این لیست ارسال هر چند ثانیه یکبار به روز رسانی گردد.

**5. محتوای پیام:** با استفاده از این گزینه می توانید محتوای پیام ارسال شده را مشاهده کنید.

**6. حذف:** می توانید سابقه پیام ارسال شده را حذف کنید، کافی است پیام های مورد نظر را با تیک انتخاب و سپس دکمه حذف را کلیک نمایید.

**7. فرستادن به اکسل:** می توانید لیست ارسال های انتخاب شده را در قالب فایل اکسل دریافت کنید.

**8. وضعیت تحویل  پیام کوتاه و فکس:**  نامشخص-تحویل داده شده- ناموفق

**A. نامشخص:** هنوز مرکز پاسخی برای وضعیت تحویل پیامک به مخاطب  برای نرم افزار ارسال نکرده است.

**B. تحویل داده شده:**  پیامک به مخاطب تحویل داده شده است. (Delivery Report)

**C. ناموفق:** پیامک به مخاطب تحویل داده نشده است.

**وضعیت تحویل:** انواع وضعیت تحویل ها به شرح ذیل می باشد.

**A. نامشخص:** ایمیل ارسال شده هنوز توسط مخاطب باز نشده است.

**B. تحویل داده شده:**  ایمیل ارسال شده توسط مخاطب حداقل یکبار باز شده است.

**C. ناموفق:** آدرس ایمیل مخاطب اشتباه است.

**9. وضعیت دنبال پیام کوتاه و فکس:** در حالتی که پیامک ارسال شده بتواند جواب داشته باشد (مانند پیامک های نظر سنجی، مسابقه، پاسخگوی خودکار)، وضعیت های دنبال شده به شرح ذیل است:

**A. دنبال شده:**  مخاطب پیامی در جواب پیامک ارسال کرده است.

**B. دنبال نشده:** مخاطب تا کنون پیامکی در جواب پیامک ارسال نکرده است.

**وضعیت دنبال ایمیل:** اگر ایمیل ارسال شده دارای لینک ویژه باشد:

**A. دنبال شده:** مخاطب بر روی لینک ویژه موجود در ایمیل کلیک کرده است.

**B. دنبال نشده:** مخاطب تاکنون بر روی لینک ویژه موجود در ایمیل کلیک نکرده است .

##### کلیک راست بر روی یک پیام شامل موارد زیر است:

![IMG-0875](</kb-assets/kb-images/Help/Marketing/sms/Send-ist/send2.webp>)

**جزئیات ارسال:** در این قسمت جزییات مرتبط با ارسال پیام مانند کد رهگیری و وضعیت تحویل و ارسال را می توانید مشاهده کنید.

![IMG-0876](</kb-assets/kb-images/Help/Marketing/sms/Send-ist/send3.webp>)

**سعی در ارسال دوباره:** این پیام دوباره ارسال خواهد شد .

**جستجوی پروفایل مرتبط:**  پروفایل هایی که در نرم افزار شامل این شماره و یا ایمیل هستند را نمایش می دهد .

**باز کردن پروفایل مرتبط:** در صورتی که بسته به رسانه تبلیغاتی، اطلاعات شماره و یا ایمیل موردنظر، در پیام گستر ثبت شده باشد، با انتخاب این گزینه پروفایل مربوط به این شماره و یا ایمیل بازخواهد شد.

**اضافه به گروه:** در صورتی که شماره و یا ایمیل مربوط به یک پروفایل در پیام گستر باشد، می توان از همین بخش آن را به گروه هدف خاصی برای پیگیری های آینده اضافه نمود .

## مودم‌های GSM قابل پشتیبانی
`مسیر سند: Help/Marketing/sms/gsm/modem-gsm.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/gsm/modem-gsm.md)

ارتباط نرم افزار پیام گستر با GSM مودم جهت ارسال پیام، با یکی از سه برند ذیل امکان پذیر می باشد.

**برندهایی که برای خرید توصیه می‌شوند:**

- T-mobile

- Dlink

- Data net

> نکته: با توجه به اینکه GSM مودم روی سرورهای مجازی شناسایی نمی شود حتما باید روی سرور پیام گستر به صورت فیزیکی باشد.

لازم به ذکر است GSM مودم می‌بایست به صورت DONGLE باشد. مانند تصاویر زیر:

![IMG-0877](</kb-assets/kb-images/Help/Marketing/sms/gsm/gsm1.webp>)

![IMG-0878](</kb-assets/kb-images/Help/Marketing/sms/gsm/gsm2.webp>)

## تنظیم GSM مودم
`مسیر سند: Help/Marketing/sms/gsm/modm-gsm-set.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/gsm/modm-gsm-set.md)

Gsm Modem می بایست حتما به پورت های Usb پشت سرور پیام گستر متصل شود .زیرا تنظیمات می بایست بر روی PayamGostarAgentConfiguration انجام شود.

 در صورتی که پشت سرور جای خالی برای متصل کردن نبود،می بایست از Hub Usb استفاده شود.

1- از قسمت DeviceManager - Modems - بر روی device موردنظر کلیک راست کنید و properties را انتخاب کنید.

2- دکمه query را انتخاب کنید. مودم می‌بایست query دهد.

3- سپس نرم‌افزار مربوط به Gsm را از خود GSM ای که متصل کرده اید نصب کنید، یکبار نرم افزار GSM را باز کرده و از طریق آن اقدام به ارسال پیام کنید.

در صورت ارسال شدن پیام، نرم‌افزار را ببندید که پورت مربوطه اشغال نشود. (endtask کنید.)

**ارتباط GSM با پیام‌گستر:**

وارد PayamGostarAgentConfiguration شده و به قسمت GSM بروید. detect را زده و پورت مربوطه را انتخاب کنید.

**تست با نرم افزار پیام گستر:**

قبل از تست مطمئن شوید نرم‌افزار مربوط به GSM حتما بسته باشد، برای تست ارسال وارد نرم‌افزار شده و در قسمت ارسال گروهی پیام کوتاه،گام اول خط مربوطه را روی GSM تنظیم کنید. پورت انتخاب شده می‌بایست نمایان شود و حالا می‌توانید ارسال کنید.

> **نکته:** می‌توان بیش از یک GSM مودم را به سرور پیام گستر وصل و کانفیگ نمود.

لازم به ذکر است، در صورتی که پورت اتصال به GSM را عوض کردید و ارسال انجام نمی‌شد  و در جزئیات ارسال خطای Server difficulty نمایش داده می‌شد. می‌بایست یکبار با برنامه مربوط به خود GSM ارسال انجام دهید و سپس مجدد با برنامه تلاش کنید.

> با توجه به افزایش روزافزون استفاده از GSM به دلیل بسته شدن دریافت پیامک‌های تبلیغاتی توسط افراد، اپراتورهای ارسال کننده (مانند همراه اول) در صورتی که از خطوط موبایل نیز شکایتی دریافت کنند، شماره مربوطه را بلاک می‌نمایند. در نتیجه در صورتی که پیامک ارسال نمی‌شد حتما با برنامه GSM پیام را ارسال نمایید. اگر با داشتن شارژ همچنان ارسال انجام نمی‌شد. ممکن است به دلیل بلاک شدن شماره موبایل مربوطه در GSM باشد.

## لیست پیامک‌های دریافتی
`مسیر سند: Help/Marketing/sms/resive-list/resive-list.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/resive-list/resive-list.md)

در یک برنامه تبلیغاتی برای مشاهده لیست پیام‌هاي دریافتی از مسير **ابزار تبليغات** > **پيام کوتاه** > **ليست پيام‌هاي دریافتی** اقدام کنيد.

برای مشاهده لیست پیام‌های دریافتی، کاربر نیاز به مجوز مشاهده ليست پيام‌های دريافتي دارد.

در این پنجره تمام پیام کوتاه‌هایی که به شماره شما ارسال شده است، شماره خط دریافتی، ارسال کننده، شماره آن و همچنین تاریخ دریافت نمایش داده می شود.

![IMG-0879: لیست پیام‌های دریافتی](</kb-assets/kb-images/Help/Marketing/sms/resive-list/ListofReceivingMessages.webp>)

**1.محتوای پیام**: با استفاده از این گزینه محتوای پیام‌های دریافتی قابل مشاهده است.

**2. حذف**: برای حذف سابقه پیام دریافت‌شده کافی است پیام‌های مورد نظر را با تیک انتخاب و سپس دکمه حذف را کلیک کنید.

**3. فرستادن به اکسل**: با استفاده از اين گزينه می‌توانید لیست در‌یافت‌های انتخاب‌شده را در قالب فایل اکسل دریافت کنید.

4. با کليک راست بر روي يک پيام گزينه‌هاي زير مشاهده مي‌شود:

**جستجوی پروفایل مرتبط**: پروفایل‌هایی را که در نرم‌افزار شامل این شماره هستند نمایش می‌دهد.

**بازکردن پروفایل مرتبط**: در صورتی که بسته به رسانه تبلیغاتی، اطلاعات شماره موردنظر، در پیام گستر ثبت شده باشد، با انتخاب این گزینه پروفایل مربوط به این شماره باز خواهد شد.

**اضافه به گروه**: در صورتی که شماره مربوط به یک پروفایل در پیام گستر باشد، می‌توان از همین بخش آن را به گروه هدف خاصی برای پیگیری‌های آینده اضافه نمود.

 می‌توان لیست پیام‌ها را با فاکتورهایی مانند تاریخ دریافت، یا بازه‌ای بین دو تاریخ، شماره خط ارسال‌کننده، خط دریافتی فیلتر کرد.

![IMG-0880: فیلتر پیام‌های دریافتی](</kb-assets/kb-images/Help/Marketing/sms/resive-list/FilterReceivingMessage.webp>)

**1.خط**: خط دریافت‌کننده پیامک را در این قسمت مشخص کنید.

**2.ارسال‌کننده**: شماره خط ارسال‌کننده را در این قسمت وارد کنید.

**3. از تاریخ/تا تاریخ**: ابتدا و انتهای بازه زمانی دریافت را در این قسمت مشخص کنید.

**4. فقط پیام‌هایی که به هیچ برنامه‌ای مربوط نیستند**: پیام‌هایی نمایش داده می‌شود که مخاطب به شماره شما ارسال کرده است، اما مربوط به برنامه‌های تبلیغاتی مثل مسابقه نیست.

**5. دریافت آخرین وضعیت پیام‌ها از مرکز**: با فعال‌کردن این گزینه، کلید فیلتر علاوه بر اعمال فیلترهای تعیین‌شده، آخرین وضعیت ارسال و تحویل پیام‌ها را از سرور دریافت خواهد کرد.

**6. به‌روزرسانی لیست**: با استفاده از این گزینه می‌توانید تعیین کنید که این لیست دریافت، هر چند ثانیه یکبار به‌روزرسانی شود.

## مدیریت ارسال گروهی پیامک
`مسیر سند: Help/Marketing/sms/send-group/send-group.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Marketing/sms/send-group/send-group.md)

در این قسمت امکان تعریف برنامه های ارسال گروهی برای مخاطبان مورد نظر وجود دارد

.لطفا ابتدا اطلاعات مشترک ابزارها را مطالعه فرمایید و طبق گام های زیر برای ارسال گروهی جدید اقدام فرمایید.

[گام اول - اطلاعات اولیه ارسال گرو هی](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20yk/gam-yk.md)

[گام دوم - محتوای پیام](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20do/gam-do.md)

[گام سوم -انتخاب مخاطبان](https://github.com/1stco/PayamGostarDocs/blob/master/Help/Marketing/moshtarak-abzar/gam%20se/select-Audience.md)

برای اجرای یک برنامه جدید باید بر روی دکمه"ارسال گروهی جدید" در سمت راست و بالای صفحه کلیک کرده و با گذراندن چند گام ساده، برنامه را به راحتی اجرا کنید.

لیست برنامه های تنظیم شده ی قبلی  در کادر پایین صفحه نمایش داده می شود و از همین قسمت می توانید تاریخ اجرا، وضعیت برنامه را مشاهده کنید و همچنین با کلیک بر روی مشاهده تحلیل نتایج برنامه ، نتایج ارسال و نمودارهای تحلیلی برنامه را مشاهده کنید.

![IMG-0881](</kb-assets/kb-images/Help/Marketing/sms/send-group/advertising-sendinggroupsms.webp>)

> نکته:  برنامه هایی که وضعیت آن ها تمام شده است قابلیت ویرایش ندارند و ویرایش تنها برای برنامه های تازه درج شده است.

> نکته: می توان با تعیین عنوان برنامه و یا تاریخ اجرا و زدن دکمه فیلتر، لیست برنامه های اجرا شده در گذشته را بر اساس پارامتر مشخص شده مشاهده کرد.

**وضعیت:**  در این ستون، می توانید وضعیت فعلی ارسال فردی/گروهی را مشاهده نمایید. حالت تمام شده به معنای  تشکیل لیست کامل مخاطبان است. تازه درج شده به معنای ثبت برنامه و درانتظار جهت ارسال (ایجاد لیست ارسال) می باشد. در حال اجرا  یعنی لیست ارسال بصورت کامل تشکیل نشده است ، ممکن است برنامه برای مثال دوره ای باشد و تا پایان کامل در حال اجرا نمایش داده می شود .
