# مستندات رسمی پیام‌گستر — Help-Settings-Currency-setting

منبع: مخزن رسمی 1stco/PayamGostarDocs (commit e6143c66b174، ۱۴۰۵/۰۶/۱۴) — متن مقاله‌های help.payamgostar.com/docs. تصاویر به‌صورت پیوند `![IMG-…](</kb-assets/kb-images/…>)` (مسیر از ریشه مخزن PGSkill) آمده‌اند؛ متن داخل تصویر جست‌وجو نمی‌شود. فهرست تصاویر: `references/kb-images-index.csv`.

## تنظیمات ارز
`مسیر سند: Help/Settings/Currency-setting/Currency-setting.md` · [منبع](https://github.com/1stco/PayamGostarDocs/blob/e6143c66b1746f251ae840745e7fe070607aee10/Help/Settings/Currency-setting/Currency-setting.md)

در این قسمت ارز های تعریف شده در سیستم و تعداد رقم اعشار آن نمایش داده می شود.
در حال حاضر فقط ارز ریال در سیستم قابل استفاده است.

در قسمت ویرایش می توانید تعداد رقم اعشار ریال را حداکثر تا 2 رقم اعشار تنظیم کنید.

![IMG-1084](</kb-assets/kb-images/Help/Settings/Currency-setting/1.webp>)

> نکته: تعداد رقم اعشار زمانی استفاده می شود که قصد انتخاب قیمت گذاری در لیست قیمت بر اساس رقم را داشته باشید. به علاوه، برای فیلد های اضافه از نوع پول، برای تنظیم تعداد رقم اعشار آن از این تنظیمات استفاده می شود.
